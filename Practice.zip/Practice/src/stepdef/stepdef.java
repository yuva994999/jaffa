package stepdef;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class stepdef
{
	WebDriver d ; 
	@Given("^Open BOI web site$")
	public void open_BOI_web_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shongalk\\Desktop\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
  	  d=new ChromeDriver();
      d.get("https://www.bankofindia.co.in/");
      d.manage().window().maximize(); //throw new PendingException();
	}

	@Then("^Display its present$")
	public void display_its_present() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		//boolean e1=d.getPageSource().contains("Rural");
		//boolean a=e1.isDisplayed();
		//boolean a=
		WebElement e1=d.findElement(By.xpath("/html/body/header/div[2]/div[4]/ul/li[3]/a[1]"));//.isDisplayed();
		if(e1.isDisplayed()) {
			System.out.println("rural is present-no defect");
		}
		else {
			System.out.println("rural not present-defect");
		}
	}
	// /html/body/header/div[2]/div[2]/a[1]/img
	// /html/body/header/div[2]/div[4]/ul/li[3]/a[1]
	@Then("^check for logo$")
	public void check_for_logo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		boolean a=d.findElement(By.xpath("/html/body/header/div[2]/div[2]/a[1]/img")).isDisplayed();
		if(a) {
			System.out.println("image present-no defect");
		}
		else {
			System.out.println("image not present-defect");
		}
	}
	// /html/body/div/div[2]/div/div/div[9]
	// /html/body/div/div[2]/div/div/div[2]
	@When("^Click on contact us$")
	public void click_on_contact_us() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	//locate us
		WebElement e2=d.findElement(By.xpath("/html/body/div/div[2]/div/div/div[7]"));
		Actions a=new Actions(d);
		a.moveToElement(e2).click().build().perform();
	}

	@Then("^check if list is present$")
	public void check_if_list_is_present() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		// /html/body/div/div[2]/div/div/div[8]/div/div[2]/div/ul/li[1]/a----branch
		// /html/body/div/div[2]/div/div/div[3]/div/div[2]/div/ul/li[1]/a
		Thread.sleep(10000);
		WebElement e3=d.findElement(By.linkText("Branch"));//branch
		
		if(e3.isDisplayed()) {
			System.out.println("branch displayed-no defect");
		}
		else {
			System.out.println("branch not displayed-a defect");
		}
		Actions a1=new Actions(d);
		a1.moveToElement(e3).click().build().perform();
	}
	
	@Then("^Enter details$")
	public void enter_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		d.findElement(By.name("BranchName")).sendKeys("bangalore");
	}


// /html/body/header/div[2]/div[2]/a[1]/img
}
